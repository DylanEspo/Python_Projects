# Author: Dylan Esposito
# Due Date:November 21,2016
# Program: to find all possible alignments of a pair of strings when adding
# gaps to the shorter string

#Two variables are created here that will cacluate the gap_work done and the
#amount of work done to compare each and every character.
gap_work = 0
compare_work = 0

def insertOneGap(strng):
    alignments = []
    #Everything is the same as before except we added the variable gap_work.
    global gap_work
    for i in range(len(strng)):
        newStrng = strng[0:i] + '-' + strng[i:len(strng)]
        alignments = alignments + [newStrng]
        #Here we increment gap_work by one.
        gap_work = gap_work + 1
    alignments = alignments + [strng + '-']
    return alignments
            
# Function to take a set union of a pair of lists
# This is used to eliminate any duplicates in the list when they are combined
def Union(list1, list2):
    for a in list2:
        if a not in list1:
            list1 = list1 + [a]
    return list1


# Function to create all possible alignments of a string with a certain number
# of gaps inserted
def insertAllGaps(strng, gaps):
    # List of alignments starts with the initial string
    alignments = [strng]

    # Loop to insert one gap at a time
    for i in range(gaps):

        # Initialize list of new alignments with i gaps in the string
        newAlignments = []

        # For every string in the list of alignments
        for st in alignments:
            # Insert one gap in each alignment in the list
            al = insertOneGap(st)

            # Add the new alignment to the list of new alignments being created
            newAlignments = Union(newAlignments,al)

        # The alignments list now becomes the new alignments list to now
        # add another gap to each of the alignments in the new list
        alignments = newAlignments
    return alignments


# Function to print all of the alignments 

def printResults(st, alignments):
    #Here we print the length of alignments to tell how many alignments there are.
    print("There are ", len(alignments), " alignments")
    #Create a variable maxScore that will find the max score.
    maxScore = 0
    #Create a list that will store the values of each score computed.
    score = []
    #Counter variable that increments through the loop.
    i = 0

    #Here we store all the scores as well as figure out the maxScore.    
    while i < len(alignments):
        #The score list appends the value returned when we call the calculateScores function.
        score.append(calculateScores(alignments[i], st))

        #Check to see if the current element in score is larger than the maxScore.
        if score[i] >= maxScore:
            #If so we maxScore equal to the value of that element.
            maxScore = score[i]
        #Finally we increment i by one.
        i = i + 1
        
    #Now we check to see which scores meet the criteria of the maxScore.
    for j in range(len(score)):
        #Here we check to see if the current element of score is equal to maxScore.
        if score[j] == maxScore:
            #If so we print the first string, the alignment and the score.
            #We also print an empty line in order to separate each function.
            print(st)
            print(alignments[j])
            print("The score is", score[j])
            print(" ")
    return       

#This function calculates the scores of the short and long string alignments.
def calculateScores(string1, string2):

    #Create four vairables titled q, score, gap and match.
    #q serves as a counter to increment through the loop.
    #Match and gaps serve as counter variables thatt determine how many
    #matches and gaps are in the alignment.
    
    q = 0
    score = 0
    gap = 0
    match = 0
    #Pass the compare_work variable here.
    global compare_work

    while q < len(string2):
        #Compare corresponding letters in both strings with one another.
        if string1[q] == string2[q]:
            #Increment by one if match found.
            match = match + 1
        #Else if there is a dash in string one.
        elif string1[q] == "-":
            #Decrement gap by one.
            gap = gap - 1
        #Each time through we increment compare_work and q by one.
        compare_work = compare_work + 1
        q = q + 1
    #Afterwords we add the values of match and gap together to find the score.
    score = match + gap
    #We end the function by returning the score.
    return score
    
# Main function

def main():
    # Get the two strings to align
    str1 = input("Enter string 1: ")
    str2 = input("Enter string 2: ")
    global gap_work
    global compare_work
    # Compute alignments adding gaps to the shorter string
    if len(str1) > len(str2):
        longStr = str1
        shortStr = str2
    else:
        longStr = str2
        shortStr = str1

    alignments = insertAllGaps(shortStr,len(longStr)-len(shortStr))
    printResults(longStr,alignments)
    
    #Here we print out both the gap_work and the compare_work at the end.
    print("The amount of work done(gaps):",gap_work)
    print("The amount of work done(comparisons):",compare_work)
    
