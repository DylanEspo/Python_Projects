#Author: Dylan Esposito
#Due Date: October 31, 2016
#Homework 7 Question 1
#Purpose: Create a function that can decript a casear cipher.

def decript(ciphertext, key):
    alphabet=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
    #First we initalize plainttext as a blank string
    plaintext = ""

    #In the loop we follow a similair process as creating the casear cipher
    #except we subtract the shift from the ciphertext.
    for i in range(len(ciphertext)):
        #Here we create a variable letter and set it equal to the
        #current index of ciphertext.
        letter = ciphertext[i]

        #Next we create a variable called alpha_num that is set equal to the retrieved
        #index as determined by the letter variable.
        alpha_num = alphabet.index(letter)

        #From there we create a variable called plain_letter and set it equal to
        #the value of alpha_num subtracted by key than modded by the length of
        #alphabet, in this case, 26.
        plain_num = (alpha_num - key) % len(alphabet)

        #From there we set plain_letter equal to the index of alphabet with
        #plainNum plugged in. This retrieves the original letter of the plaintext.
        plain_letter = alphabet[plain_num]

        #From there we add the retrieved letter to the plaintext.
        plaintext = plaintext + plain_letter

    #Once we have finished we return plaintext.
    return plaintext

    
