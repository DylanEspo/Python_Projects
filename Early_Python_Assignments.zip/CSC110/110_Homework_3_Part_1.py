#Author: Dylan Esposito
#Due Date of Assignment: September 26, 2016
#Title: Homework 3 Question 1
#Purpose: This program is meant to compile a list of cars and theirs speeds.
#Then determine which ones are traveling over the speed limit.

#Gets the number of cars that passed the sensor.
carList = []
#Here I am asking the user to enter the number of cars that will have their speed checked.
num_cars = int(input("Enter the number of cars that have passed the sensor: "))

#I also intialize a variable called i which helps us progress through the loop.
i = 1

#Gets the data (the list of speeds) from the user and stores it in a list.
#Here we use a while loop to get all that data and store it within a list.
#The loop knows when to stop since we set the limit to when we reach the value of num_cars
while i <= num_cars:
    #The speedOfCar variable is simple and just adds for the speed of the specific car.
    speedOfCar = int(input("Enter the speed of car " + str(i) + ": "))
    #After the car and it's speed are added to the carList.
    carList = carList + [speedOfCar]
    #From there we increment i by one.
    i = i + 1
    #end of loop
    
#Here I create a separate list that will store the cars that are over the speed limit.    
speedingTotal = []
#I also created a speeding count to keep track of the number of cars found to be going over
#the limit.
speedingCount = 0
#Gets a speed limit from the user.
speedLimit = int(input("What is the speed limit? "))

#Here I create a variable called j which will helps us progress through the loop.
j = 0

#This while loop is used to compute the number of speeds that exceed the limit.
#The limit again is determined by the number of cars in the list.
while j < num_cars:
    if carList[j] > speedLimit:
        speedingTotal = speedingTotal + [carList[j]]
        speedingCount = speedingCount + 1
    j = j + 1
    #end of loop

#Below I created both an if and else statement that will be called depending
#on the number of cars speeding.
if carList == 0:
    print("No cars were over the speed limit")
else:
    #We get the percentage of cars that went over the speed limit through this float.
    #All we do is divide the speedingCount and the number of cars to get a percentage.
    #After we multiply the percentage by one hundred so it prints in the correct decimal place.
    perOver = 100*(float(speedingCount/num_cars))
    #Prints the percentage of cars that have exceeded the speed limit.
    print("The percentage of cars that were speeding is", perOver, "%")
