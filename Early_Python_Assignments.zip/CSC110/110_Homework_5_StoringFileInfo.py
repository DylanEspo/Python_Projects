#Author: Dylan Esposito
#Due Date: October 10, 2016
#Title: Data Operations Assignment
#Purpose: To store information surrounding the summer olympics and
#return that information to the user.

yearList = []
locationList = []

#This function collections information from the file and then stores it
#into lists.
def storeInfo():

    #A variable called infile is defined and it calls the openFile function
    infile = openFile()
    #From here we define a variable called line that reads the current
    #line of the file.
    line = infile.readline()
    #Here we then assign the strip function to the variable. It removes
    #all the whitespace.
    line = line.strip()
    #The variable i is assigned to zero.
    i = 0

    #Here we create a while loop that increments through the text file and
    #sepearates each and every line into a list.
    while i < 32:
        #Here we separate the lines of year and location via the split
        #function. This function will separate the lines upon reaching a
        #specific character. It will also remove that character from the
        #lists.
        year, loc = line.split("\t")
        #Here the array yearList will add the current year line to its collection.
        yearList.append(year)
        #Again locationList will add the current location line to its collection.
        locationList.append(loc)
        #After the line will read the current line to make sure we all completed.
        line = infile.readline()
        #After words we strip any of the remaining white space so we can move on
        #to the next line.
        line = line.strip()
        #Before we are done we increment i by one to process through the text file.
        i = i + 1

    #Once we complete the list we return both the yearList and locationList
    return yearList, locationList

#Here we created function titled openFile that checks to see if the file requested to
#be opened actually exists.
def openFile():

    #Here we create a variable i that is set equal to zero.
    i = 0
    #Here the loop will run until i is not equal to zero.
    while i == 0:
        #We make use of a try and except system that will check to
        #see if the file entered actually exists or not.
        try:
            #The fileName is a variable that has an input assigned to it.
            #In this case the input must be the name of a file followed by .txt
            fileName = input("Please enter the name of the data file: ")
            #If the file is found then we open it and assign it the read operation
            #since all we want to do is collect information from it.
            infile = open(fileName, 'r')
            #From there we end the loop by assigning i equal to one.
            i = 1
            
        #In the except circumstance, we state it is an IOError and
        #we have the compiler return a message to the user.
        except IOError:
            #Here we tell the user that the file does not exist and we ask
            #them to reenter a file that does exist.
            print("File does not exist, try again")
            
    #After we are done we return infile, which is the operation that called the
    #file to be opened.
    return infile

#Here we create a function title findLoc. The purpose of this function is
#to ask the user for any year they want. If the year corresponds to a year
#that the Summer Olympics were held, it will return the location of that specific
#olympics. 
def findLoc():
    #To start the function. We prompt the user to enter a year and see if the
    #olympics were held that year.
    yearEntered = input("Please enter what year you are interested in: ")
    #We create a variable titled valueSet that controls the flow of the loop.
    #If the entered year is found to correspond to the year the user entered, then
    #the program will end the loop by settting valueSet to False.
    valueSet = False
    #Here we create another variable titled j which is set to zero. While it
    #does not exactly determine when the loop ends, it will assist in incrementing
    #through the lists to see if the user input is equal to one of the lines
    #in the list.
    j = 0

    #Here we make use of a while loop to increment through the lists.
    while valueSet != True:
        
        #First we check if the yearEntered is equal to the value stored in the
        #yearList. If so we must also go through a series of if statements to
        #check the value.
        if yearEntered == yearList[j]:
            #To start off we check if the input is equal to 1940 or 1944. If so
            #then we inform the user that while the years were present in the list
            #no Olympics were held during that tiem.
            if yearEntered == "1940" or yearEntered == "1944":
                #Here we print that no olympics were held in the year that the user inputed.
                print("No olympics were in held in", yearEntered)
                #Afterwords, we set the variable valueSet to True so we can end the loop.
                valueSet = True
            #This else statement is called when the user input is not equal to 1940 or 1944.
            #This else statement confirms that the olympics were held and that they were held in a specific
            #location.
            else:
                #Here we print that the user's input had a Olympics held during a specific year. Since each index of the locationList
                #corresponds to the indexs in yearList, we just call the locationList with the current value of j inside it.
                print("In",yearEntered,"the Olympics were held in", locationList[j])
                #To end the loop we put valueSet to True.
                valueSet = True
        #In this if statement we check to see if yearEntered has still not equal the value in the list.
        #If is equal to 31 then we just print that olympics were not held in the year entered. 
        if yearEntered != yearList[j] and j == 31:
            print("No olympics were held in", yearEntered)
            valueSet = True
        #If both if statements are not foudn to be true, we continue through the loop. 
        j = j + 1
                            
def main():
    storeInfo()
    findLoc()
    
