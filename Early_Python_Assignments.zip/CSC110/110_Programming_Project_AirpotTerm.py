#Author: Dylan Esposito
#Tilte: Programming Project - Airline
#Due Date: 12/10/16

def main():
    #Create five lists and set them equal to the values returned from getFlights.
    airline, airCode, departTime, arriveTime, price = getFlights()
    #Call the makeDecisions functions and enter in all the variables.
    makeDecisions(airline, airCode, departTime, arriveTime, price)

def openFile():
    #Set i to zero.
    i = 0
    while i == 0:
        #Check to see if the filename exists
        #Otherwise ask for the user to return the file.
        try:
            #fileName is an input value.
            fileName = input("What file do you want to run? ")
            #Check to see if the value exists, set it to read.
            infile = open(fileName, 'r')
            #Set i to one.
            i = 1
        except IOError:
            print("File does not exist, try again")         
    #End funciton by returning value.
    return infile

def getFlights():
    # This function will get the data from the data file - be sure to look at the format of the data in the
    # file and read each line as we did with the phone search program in class.
    # The function should return the list of years, the list of winners and the list of losers
    #initialize lists
    airline = []
    airCode = []
    departTime = []
    arriveTime = []
    price = []
    
    #Open file
    infile = openFile()
    #get first line and strip it
    line = infile.readline()
    line = line.strip()

    #check all other lines and store information in appropriate lists
    while line != '':
        #Split each time there is a comma
        line = line.split(',')
        #Have airline append the fist line
        airline.append(line[0])
        #Have airCode append the second line
        airCode.append(line[1])
        #Have deparTime append the third line.
        departTime.append(line[2])
        #Have arriveTime append the fourth time.
        arriveTime.append(line[3])
        #Have price append the last line.
        price.append(line[4])
        #Complete reading this line
        line = infile.readline()
        #Strip everything and repeat the process
        line = line.strip()
                            

    #return results
    return airline,airCode,departTime,arriveTime,price

#option1 that checks to see which flights belong to which airline company
def flightsOnAirline(airline, airCode, departTime, arriveTime, price, enteredLine):
    #Creates a counter variable called i that is set to zero
    i = 0

    #counter that will determine how many values were called.
    x = 0
    #Call helper function displayPromt which print outs the table to categorize values.
    displayPrompt()
    
    #This loop iterates thorugh the airline list to see if the entered airline
    #exists.
    while i < len(airline):
        #If the airline is found to be equal to the entered airline, it is added
        #to the list
        if airline[i] == enteredLine:
            #check to see if airline entered is JetBlue. If so we edit the alignment on that specific line.
            if airline[i] == "JetBlue":
                print(airline[i],"",airCode[i],"\t",departTime[i],"\t",arriveTime[i],"\t",price[i])
            else:
                print(airline[i],"\t", airCode[i],"\t",departTime[i],"\t",arriveTime[i],"\t",price[i])
            #increments x by one
            x = x + 1
        #We increment i by one.
        i = i  + 1
    #checks to see if x is equal to zero. Indicating the flight does not exist.
    if x == 0:
        print("No flights meet the criteria, check to see if airline exists")

    #Empty return 
    return

#option2 that checks to see which flight is the cheapest
def cheapestFlight(airline, airCode, price):
    #Create a counter j
    j = 0
    #Create an integer x that will serve to represent the number of values drawn from the airline.
    x = 0
    #PriceConvert is a list value of the prices returned when we call the convertPrice funciton.
    priceConvert = convertPrice(price)
    #Set cheapestPrice to zero.
    cheapestPrice = 0

    #Here we check to see if while is less than the length of the price array
    while j < len(price):
        #From there we check to see if j is less than one. If so we set cheapestPrice to
        #the first element of priceConvert
        if j < 1:
            cheapestPrice = priceConvert[0]
        #However if j is greater than one we check to see if the current element is less than
        #the saved value of cheapestPrice, if so we set cheapestPrice equal to that element.
        elif priceConvert[j] < cheapestPrice:
            cheapestPrice = priceConvert[j]
            x = j
        #We increment j by one.
        j = j + 1
    #With the loop finished we print the value of cheapestPrice
    print("The cheapest value is",airline[x],airCode[x],"at $",cheapestPrice)

    #empty return to end the funciton.
    return
    
#option3
def cheaperThanSpecified(airline, airCode, departTime, arriveTime, price):

    #Check to make sure the funciton does not crash if an invalid value is entered.
    #If an invalid value is entered, then we just return that the value is correct and return to the choice menu.
    try:
        #Ask the user to input the maximum price they can afford.
        cheaperValue = int(input("Enter your maximum price: "))
        #Create two variables j and x that will be incremented depending on the price entered.
        j = 0
        x = 0
        #Call the convertPrice function.
        newPrice = convertPrice(price)
        #Calls displayPrompt helper function.
        displayPrompt()

        #Loop to go through and check to see which prices meet the criteria.
        while j < len(price):
            #Checks to see if the current index in newPrice is less than the specified chearpValue
            if newPrice[j] < cheaperValue:
                if airline[j] == "JetBlue":
                    print(airline[j],"",airCode[j],"\t",departTime[j],"\t",arriveTime[j],"\t",price[j])
                else:
                    print(airline[j],"\t", airCode[j],"\t",departTime[j],"\t",arriveTime[j],"\t",price[j])
                #increments x by one.
                x = x + 1
            #Increment j by one regardless
            j = j + 1
        #If max price is too small, inform the user that no price meets that criteria
        if x == 0:
            print("No flights meet this criteria")
            return cheaperValue
        else:
        #Else end the function by returning a value
        #Need to check to see if priceConvert is empty
            return cheaperValue
    except ValueError:
        print("Invalid value entered, try enetering a whole number")
        return
    
#option4      
def shortestFlight(airline, airCode, departTime, arriveTime):

    #Create counter variable j.
    j = 0
    #Create two variables called shortest and current.
    shortest = 0
    current = 0
    #Create two variables set equal to the current elements of airline and airCode
    currAirline = airline[j]
    currAirCode = airCode[j]
    i = 0
    #Set flightTimes equal to the value returned by the flightLength function.
    flightTimes = flightLength(departTime, arriveTime)
    #Next we check to see if the what is the shortest time in the list
    #of flightTimes.
    while j < len(flightTimes):
        
        #We start off by setting the variable currentTIme equal to the current element of flightTImes.
        current = flightTimes[j]
        
        #Next we check to see if j is elss than one.
        if j < 1:
            #If so we set the variable shortestTime equal to currentTime
            shortest = current
            #Set currAirline to the element of airline at index j.
            currAirline = airline[j]
            #Set currAirCode to the element of the airCode at index j.
            currAirCode = airCode[j]
            
        #If currentTime is less than the shorestTime stored then set shortestTime equal to currentTime.
        elif current < shortest:
            #If so we set the variable shortestTime equal to currentTime
            shortest = current
            #Set currAirline to the element of airline at index j.
            currAirline = airline[j]
            #Set currAirCode to the element of the airCode at index j.
        #Increment j by one.
        j = j + 1
    #Once we are done we print the shortestTime value.
    print("The shortest flight available is",currAirline, currAirCode, "at", int(shortest),"minutes")

#Option 5
def flightDepartingAtSpecificTime(airline, airCode, departTime, arriveTime, price):

    #Check to make sure the funciton does not crash if an invalid value is entered.
    #If an invalid value is entered, then we just return that the value is correct and return to the choice menu.
    try:

        #Next we set the variables earliest and latest equal to the output
        #of computeEarliestLatest
        earliest, latest = computeEarliestLatest()
        depTemp = []
        
        #Here we set the lists of depTemp equal to the function listToInt
        depTemp = timeToInt(departTime)
        
        #Next we call the display prompt which helps organize the information.
        displayPrompt()
        #Used to count and see how many flights met the criteria.
        x = 0
        #Increment through airlines and check to see which values fall into the range specified by earliest and latest.
        for q in range(len(airline)):
            #Check to see ivalue of depTemp is >= earliest and <= or equal to the latest. Check to see if times fall into range.
            if depTemp[q] >= int(earliest) and depTemp[q] <= int(latest):
                #If the above conditional statement is met, then we print the values of the list.
                #Check to keep values aligned since JetBlue will disorganize the lineup.
                if airline[q] == "JetBlue":
                    print(airline[q],"",airCode[q],"\t",departTime[q],"\t",arriveTime[q],"\t",price[q])
                else:
                    print(airline[q],"\t",airCode[q],"\t",departTime[q],"\t",arriveTime[q],"\t",price[q])
                #Increments x by one if a value is found, regardless of what type it is.
                x = x + 1
        #checks to see if x is equal to zero. If so we print that no flights met the criteria
        if x==0:
            print("No flights met the criteria")
        #Empty return to end the function and return to get choice
        return
    #If a value error is reached
    #Inform the user that the value is incorrect and we end the function.
    except ValueError:
        print("Value is incorrect")
        return

#option6  
def averagePrice(airline, price, airName):
    #Creates a counter variable called i that is set to zero
    x = 0
    j = 0
    #Set priceConvert to the function convertPrice
    priceConvert = convertPrice(price)
    
    #Create the variables totalPrice and findAverage
    totalPrice = 0
    findAverage = 0
    #Increment through all the values that belong to the current airline.
    while j < len(airline):
        #Check to see if the current element of airline is equal to 
        if airline[j] == airName:
            #If true set totalPrice to the itself plus the current element of priceConvert
            totalPrice = totalPrice + priceConvert[j]
            #Increment x by one. This indicates the number of flights in the airline.
            x = x + 1
        #Increment j by one.
        j = j + 1
    #Value that checks to see if the flight exists. If equal to zero, airline doesn't exist.
    if x == 0:
        #Print airline doesn't exist and return nothing
        print("Airline doesn't exist, try again")
        return
    #if airline does exist, then retry.
    else:
        #If so set findAverage equal to the totalPrice divided by x. 
        findAverage = totalPrice/x
        #Then we print findAverage.
        print("The average price is $",findAverage)
        return 

#Helper Functions
def computeEarliestLatest():
    #Check to make sure the funciton does not crash if an invalid value is entered.
    #If an invalid value is entered, then we just return that the value is correct and return to the choice menu.
    try:
        #Ask for the earliest possible time to leave.
        earliest = input("Enter the earliest allowable departue time: ")
        #Ask for the latest possible time to leave.
        latest = input("Enter the latest allowable depature time: ")
        #Remove the colon from earliest and replace with an empty space.
        earliest = earliest.replace(':','')
        #Remove the colon form latest and replace it with an empty space.
        latest = latest.replace(':','')
        
        #Return the values of earliest and latest.
        return earliest, latest
    except ValueError:
        print("Reenter valid number that looks like 1500 or 15:00")
        return
    
#Converts price into an integer
def convertPrice(price):
    priceConvert = []
    i = 0
    while i < len(price):
        #First we have to remove the dollar sign in the price array in order
        #for us to convert the value to an integer. We replace it with an empty string.)
        price[i] = price[i].replace('$',"")

        #Next we have the priceConvert append the current element of price to the
        #list priceCovert
        priceConvert.append(int(price[i]))
        
        #print(priceConvert[i])Tests to see if values are added
        #Finally we increment i by one
        i = i + 1
    return priceConvert

def displayPrompt():
    #Here we print the necessary parts needed to organize the table
    print("AIRLINE"," ","FLT#","\t","DEPT","\t","ARR","\t","PRICE")
    print("------------------------------------------------------")
    
#Computes the length of each and every flight.
def flightLength(depart, arrive):
    depTime = 0
    arrTime2 = 0
    flightTimes = []
    length = 0
    i = 0
    while i < len(depart):
        #Create four empty strings that will store the hours and minutes for
        #the depart times or arrive times.
        h = ''
        m = ''
        h2 = ''
        m2 = ''        
        #First set h and m equal to the hours and minutes of the depart time
        h,m = depart[i].split(":")
        #Same for h2 and m2 only with the arrival time.
        h2, m2 = arrive[i].split(":")
        
        #Convert h and m into ints.
        h = int(h)
        m = int(m)
        #Same thing over again for h2 and m2.
        h2 = int(h2)
        m2 = int(m2)
        #Divide m by 60.
        m = m/60
        #Divide m2 by 60.
        m2 = m2/60
        #Set the variable newTime equal to the addition of h and m.
        depTime = h + m
        #Set the variable newTime2 equal to the addition of h2 and m2.
        arrTime = h2 + m2
        
        #Set length equal to the value of newTime2 minus newTime multiplied by 60.
        length = 60*(arrTime-depTime)
        
        #Append length to the flightTimes list.
        flightTimes.append(length)
        i = i + 1
    return flightTimes

#lists the options that may be chosen by the user
def getChoice():
    # This function displays the menu of choices for the user
    # It reads in the user's choice and returns it as an integer
    print("")
    print("Make a selection from the following choices:")
    print("1 - Find all flights on a particular airline")
    print("2 - Find the cheapest flight")
    print("3 - Find all flights less than a specified price")
    print("4 - Find the shortest flight")
    print("5 - Find all flights that depart within a specified range")
    print("6 - Find the average price for a specified airline")
    print("7 - Quit")
    #Check if choice made is valid
    valid = False
    #Does while loop until valid input is entered
    while not valid:
        try:
            choice = int(input("Enter your choice --> "))
            print("")
            if choice <=7 and choice>=1:
                valid = True
                print("You chose option",choice)
        except ValueError:
            print("Invalid option chosen, try again or press 7")
    return choice

#Runs the options that are made available in getChoice
def makeDecisions(airline, airCode, departTime, arriveTime, price):
    choice = getChoice()
    #We will continue to give the user options until the input is 7.
    while choice!= 7:
        #First input will check to see what flights are on which airline.
        if choice == 1:
            #Input lookingFor variable asks the user to the flight they are looking for.
            lookingFor = input("Enter the airline you are looking for: ")
            #Variable chosenLine calls the flightsOnAirline function with all the lists inside.
            chosenLine = flightsOnAirline(airline, airCode, departTime, arriveTime, price, lookingFor)
            #Set choice equal to getChoice to return to this function.
            choice = getChoice()
        #If choice equals 2, find the cheapest flight.
        if choice == 2:
            #Call chepeastFlight function.
            cheapestFlight(airline,airCode,price)
            #Call getChoice
            choice = getChoice()
        if choice == 3:
            #Call cheaperThanSpecified function with specValue inserted as parameter
            cheaperThanSpecified(airline, airCode, departTime, arriveTime, price)
            #Call getChoice
            choice = getChoice()
        if choice == 4:
            #Call shortestFlight function.
            shortestFlight(airline, airCode, departTime, arriveTime)
            #Call getChoice
            choice = getChoice()
        if choice == 5:
            #Call flightDepartingAtSpecificTime function.
            flightDepartingAtSpecificTime(airline, airCode, departTime, arriveTime, price)
            #Call getChoice
            choice = getChoice()
        if choice == 6:
            #Ask for airName
            airName = input("Enter your airline name: ")
            #Call averagePrice funciton.
            averagePrice(airline, price, airName)
            #Call getChoice
            choice = getChoice()
    print("See ya")

#Used in option 5
def timeToInt(listValues):
    #First we create a list named temp that will store the converted values.
    temp = []
    #Next we create a variable called t1
    t1 = ''
    j = 0
    #Next we increment through the listValues until all of them
    #are converted into integers.
    while j < len(listValues):
        #t1 is set equal to the current element in listValues converted to a string.
        t1 = listValues[j].replace(':','')
        #temp appends and converts t1 into a string.
        temp.append(int(t1))
        #Then we increment j by one.
        j = j + 1
    #Finally we return temp.
    return temp
