#Author: Dylan Esposito
#Due Date of Assignment: October 3
#Title: Stocks Assignment
#Purpose: This program is meant to grab stock values and organize them based
#around user input.

#The getStock function asks the user to input the names of Stocks and their values.
#This function takes two parameters, which are the name of the stocks and price.
def getStock(stockName, stockPrice):
    #To start this program, I set the the enterLimit value to false
    #as a way to determine when the user wants to end the array.
    enterLimit = False
    #The enterVal variable is what the user inputs for the stock name.
    enterVal = ''
    #The inital price of a stock is set to zero until the user puts a value into it.
    enterPrice = 0

    #The while loop is used to enter the names and values of stocks.
    #EnterLimit will only be set to True when the user enters done, to end the loop.
    while enterLimit!=True:
        #Here the enterVal variable is set to the input of the user.
        enterVal = input("Enter the name of a stock(done if finished): ")
        #If the user inputs done, it ends the loop.
        if enterVal == 'done':
            #Here the enterLimit is set to true to end the loop.
            enterLimit = True
        #This statment runs if the if statement is not found true.
        else:
            #Here stockName appends the name of the stock that the user inputed.
            stockName.append(enterVal)
            #After the user is prompted to enter the price of the stock they had just entered.
            enterPrice = int(input("Enter the price of " + enterVal + ": $"))
            #Afterwords the stockPrice array adds the price entered to its list.
            stockPrice.append(enterPrice)
    #The loop will continue prompting the user for input until done is entered.
    #Once the loop is finished we return both the stockName and the stockPrice
    return stockName, stockPrice

#This function is the searchStock function which looks for values in the stock.
def searchStock(stockName, stockPrice, s):
    #Here the loop variable j is set to zero. This will comb through the loop.
    j = 0
    #Here the s paramter is assigned to the input of the user. 
    s = input("Enter the name of the stock you want to look for: ")
    #The loop here runs through and checks to see if the parameter s equals a value in the stock.
    while j < len(stockName):
        #This is the if statement that checks if the input is equal to a stock.
        if s == stockName[j]:
            #The stockPrice is printed here.
            print("The price of", s,"is",stockPrice[j])
        #Afterwords j is incremented by one to run through the loop.
        j = j + 1
#This function is designed to take an input and figure out which stocks are the largest.
def printStock(stockName,stockPrice, p):
    #Here the user is prompted to enter the price of the stocks.
    p = int(input("Enter a price to find stocks with higher values:" ))
    #I create two new arrays, bigStocks and bigStockPrice store the stocks
    #that are larger than the inpu.
    bigStocks = []
    bigStocksPrice = []
    #I create a variable q that will go through the loop.
    q = 0
    #The loop searches through the stocks to determine which values are the largest.
    while q < len(stockName):
        #This statement attempts to figure out if stockPrice is larger than p.
        if p < stockPrice[q]:
            #Here bigStocks and bigStocksPrice append the values that were just tested.
            bigStocks.append(stockName[q])
            bigStocksPrice.append(stockPrice[q])
        else:
            print("None")
        q = q + 1
    print ("The follow stocks have prices higher than$",p,":", bigStocks)
#Here is the main function which calls the rest of the functions and allows the user to interact with the program.
def main():
    #Here I created two arrays that could be called and used for the parameters
    #of other functions.
    stocks = []
    stockPrice = []
    #I set the functions to variables so it could be simpler to use if I had
    #to call them again later.
    getter = getStock(stocks,stockPrice)
    searcher = searchStock(stocks, stockPrice, "")
    printer = printStock(stocks, stockPrice, "")
