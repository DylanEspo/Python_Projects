#Author: Dylan Esposito
#Due Date: September 19, 2016
#Assignment: Homework 2 Part 2

#Here the variable golfScore asks for the user to input their golf score on the first day.
golfScore = int(input("Enter your golf score: "))
#After the user has entered their score. We create a variable named i and set it to 2.
#Variable i is meant to be our counter for when we ask the user for input again.
i = 2
#We initalize the variable lowestScore and set it equal to the input golfScore.
#We set it equal to this because we need to initalize this variable
#outside of the loop so it can updated whenever.
lowestScore = golfScore

#A while loop is set up to repeatedly ask the user for their score over two weeks.
#Our counter variable i will allow the loop to continue to function until i equals 15. 15.
while i < 15:
    #Here the user is asked to input their score for each day.
    golfScore2 = int(input("Enter your golf score: "))
    #After the score is inputed, the input is compared to the current lowestScore.
    #If the input is found to be lower, then the lowestScore is set equal to that value.
    if golfScore2 < lowestScore:
        lowestScore = golfScore2
    #Increment the counter by one and then loop back to the top.
    i = i+1
     
#After the counter reaches it's limit and the loop ends. The lowestScore is printed out below.
print("The lowest golf score during the two weeks is: ", lowestScore)
