#Author: Dylan Esposito
#Due Date: September 19, 2016
#Assignment: Homework 2 Part 3

#The variable totalBugsCaught is meant to add up all the bugs the user catches.
#We initalize the variable by setting it to zero so it can be updated in the loop.
totalBugsCaught = 0

#We create another variable, labeled i. It is set equal to one.
#I is meant to serve as a counter variable which is updated after each loop.  
i = 1

#Here the while loop is set up and set to a limit of eight. The user only enters
#the number of bugs caught over a seven day period. So we have to stop one short.
while i < 8:
    #Here the variable bugsCaught asks the user for an input of the number of bugs caught on a specific day.
    #Here we will convert i to a string so the user knows which day it is.
    #However the input will be converted into an integer once entered.
    bugsCaught = int(input("How many bugs did you catch on day " + str(i) + "? "))
    
    #After the user inputs their value. The totalBugsCaught is then updated by
    #adding the current value of totalBugsCaught with the user input.
    totalBugsCaught = totalBugsCaught + bugsCaught
    #Before the loop repeats, we increment i by one.
    i = i + 1
#Once the loop is finished, we print out the total number of bugs Caught over the seven days.
print ("Over the seven days, you collected", totalBugsCaught,"bugs")
        
