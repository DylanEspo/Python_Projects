#Author: Dylan
#Due Date: October 24, 2016
#Homework 6 Question
#Purpose: Implement a binary function that can find the user input quicker than a linear function.

#Here we created function titled openFile that checks to see if the file requested to
#be opened actually exists.
def openFile():

    #Here we create a variable i that is set equal to zero.
    i = 0
    #Here the loop will run until i is not equal to zero.
    while i == 0:
        #We make use of a try and except system that will check to
        #see if the file entered actually exists or not.
        try:
            #The fileName is a variable that has an input assigned to it.
            #In this case the input must be the name of a file followed by .txt
            fileName = input("Please enter the name of the data file: ")
            #If the file is found then we open it and assign it the read operation
            #since all we want to do is collect information from it.
            infile = open(fileName, 'r')
            #From there we end the loop by assigning i equal to one.
            i = 1
            
        #In the except circumstance, we state it is an IOError and
        #we have the compiler return a message to the user.
        except IOError:
            #Here we tell the user that the file does not exist and we ask
            #them to reenter a file that does exist.
            print("File does not exist, try again")
            
    #After we are done we return infile, which is the operation that called the
    #file to be opened.
    return infile


# Function to get the data from the file
def getData():

    #infile is set equal to openFIle 
    infile = openFile()

    #Two empty lists are intialized, yearList and locList.
    yearList = []
    locList = []
    
    line = infile.readline()
    
    while line != "":
        #Here we separate the lines of year and location via the split
        #function. This function will separate the lines upon reaching a
        #specific character. It will also remove that character from the
        #lists.
        line = line.strip()
        year, loc = line.split("\t")
        #Here the array yearList will add the current year line to its collection.
        yearList = yearList + [int(year)]
        #Again locationList will add the current location line to its collection.
        locList = locList + [loc]
        #After the line will read the current line to make sure we all completed.
        line = infile.readline()
    infile.close()
    #Once we complete the list we return both the yearList and locationList
    return yearList, locList

def findLocation(yearList, locList, year):
    #Here we create three variables, found, i and linComp.
    #Found and i are used to go through the loop.
    found = 0
    i = 0

    #Lincomp keeps track of the number of comparisons
    #made throughout the loop.
    linComp = 0
    while found == 0 and i < len(locList):

        #First we increment lincomp by one just before we make a comparison.
        linComp = linComp + 1
        #We check to see if year is equal to the current element of yearList.
        #If so we set found equal to one and end the loop.
        if year == yearList[i]:
            found = 1
        #Here we increment i by one if the above conditional statement was not true.
        else:
            i = i + 1
    #If the value was not found we set location to an empty string.
    if found == 0:
        location = ""
    #Here we set location equal ot the index in the list where i was stopped at. 
    else:
        location = locList[i]
    #Here we print the value of linComp.
    print ("Linear search comps equals:",linComp)
    #Finally we return the location.
    return location
    

#Function that will find the year the user is looking
#for through binary search
def findLocationBinary(yearList, locList, year):
    #Initialize two variables, foudn and i which will control the loop.
    found = 0
    i = 0

    #Initialize two other variables that will be used in comparisons.
    #Right is set equal to the length of yearList subtracted by one.
    #Left is set equal to zero.
    right = len(yearList)-1
    left = 0

    #Final variables binaryComp and m will be created. Binarycomp is
    #used to count the number of iterations until the value is found.
    #M is used to go through the loop and compare values..
    binaryComp = 0;
    m = 0

    while found == 0 and right >=left:

        #First we set m equal to the sum of left and right plus one
        m = (left + right) //2

        #Before we begin we increment binaryComp by one
        binaryComp = binaryComp + 1

        #In this conditional statement, we check to see if the
        #element in yearList is equal to the year being searched
        if yearList[m] == year:
            #If the statement is true we set found to one and end the loop.
            found = 1
        #Second comparison checks to see if year is smaller than the yearList value.
        elif year < yearList[m]:
           #Right is set equal to m is one. 
            right = m - 1
        #If year is found to be greater than yearList, we set left equal to m plus one.
        else:
            left = m + 1
    #Here we check to see if found is set equal to zero.
    #If so the location is set equal to an empty string.
    if found == 0:
       location = ""
    else:
        location = locList[m]

    #Here we print the binary to tell the user how many comparisons we made.
    print ("Binary search comparisons equals:", binaryComp)

    #Here we return the locaiton.
    return location

# Function to get the year from the user - ensuring it is an integer
def getYear():
    #First we initalize a variable called goodYear, which is set equal to False
    goodYear = False

    #The loop will continue to iteratre until goodYear is set to True.
    while goodYear == False:

        #We create an input string titled yearStr which takes the given year
        #and runs it through an exception test.
        yearStr = input("Enter the year you are interested in: ")

        #The first part sets year equal to yearStr changed into an integer.
        #After we set goodYear equal to True.
        try:
            year = int(yearStr)
            goodYear = True
        #In the except clause, if there is an invalid year entered, we ask for a new value.
        except ValueError:
            print("Invalid year - must be an integer")
    #Once we are done we return the year.
    return year

# Main function
def main():
    #Here we assign yearList and locList to the function getData.
    #This fills up both lists with values.
    yearList, locList = getData()
    #From there we assign a variable year equal to getYear.
    #Here the user is prompted for a year they want to search for.
    year = getYear()

    #Here we set locaiton to two different functions.
    #The first time we set it to findLocationBinary, which performs
    #a binary search for the location the user is looking for
    location = findLocationBinary(yearList, locList, year)

    #However we then assign location equal to findLocation, which finds location
    #in using linear search. It is important to recognize that both will return the same value
    #however Binary will do it more quickly than linear.
    location = findLocation(yearList, locList, year)

    #Afterwords we check to see if location is set equal to an empty string.
    if location == "":
        #Here we print that No Olympics were held this year.
        print("No Olympics were held that year")
    else:
        #Otherwise we print the year and the location.
        print("In ",year," the Olympics were held in ",location)

    
