#Author: Dylan Esposito
#Due Date: September 19, 2016
#Assignment: Homework 2 Part 1

#First the variable salesAmount asks the user to input the value of the object
#The input is converted into a float since we are accepting values with cents in them.
salesAmount = float(input("Enter amount of sale: $"))

#Next we determine the discount given to the object.
#The first if statement only runs if the input is over $5000.00.
if salesAmount > 5000.00:
    #If the statement is found true, then the salesAmount is discounted by 25 percent.
    #Here I just subtracted the input by the value of the input multiplied by 0.25.
    print ("Your discounted sale amount is: $",salesAmount - salesAmount *0.25)
#This elif statement is run if the value of salesAmount is between $3000.00 and $5000.00
elif salesAmount >=3000 and salesAmount < 5000:
    #Here salesAmount subtracts the value of salesAmount multiplied by 20 percent
    #After subtractions are completed, we then print out the value returned.
    print("Your discounted sale amount is: $",salesAmount - salesAmount * 0.20)
#This elif statment is run if the value of salesAmount is between $1000.00 and $3000.00
elif salesAmount >=1000 and salesAmount < 3000:
    #Once again salesAmount subtracts the value of salesAmount when it is multiplied by 15 percent.
    #The value returned is then printed out.
    print("Your discounted sale amount is: $",salesAmount - salesAmount*0.15)
#This statement is the final option and is only used if none of the other levels are reached.
else:
    #Since salesAmount must be under 1000, then a 10% discount is applied.
    #Again salesAmount subtracts the value of salesAmount when it is multiplied by 10 percent.
