#Author: Dylan Esposito
#Due Date of Assignment: September 26, 2016
#Title: Homework 3 Question 2
#Purpose: This program is meant to compile a list of divisble numbers
#for a value between zero and 500.

#The program starts off asking the user for a value between 1 and 500.
number = float(input("Enter a number between 1 and 500: "))

#Next I initialize an empty list called numList.
#This list will store the divisbile values of the input.
numList = []

#With the value entered we initalize a variable called i to 500.
#Variable i will be used in the loop to determine the divisible values of the input.
i = 500

#Here I use a while loop to comb through all possible numbers that the input is
#divisble by.
#The loop ends when i is equal to zero.
while i!=0:
    #Here a check is done where i is divided by the number. However in this case
    #there is a check done to see if the remainder is equal to zero. If it is
    #then we add that resulting value to the numList.
    if i%number == 0:
        numList = numList + [i]
    #Afterwards we decrement i by one.
    i = i - 1
    #End of loop.
    
#Here we reverse the numbers collected in the list so it shows the values progress from least to most.
numList.reverse()

#After we're done we print the list and all the values that in it.
print("The resulting list is this: \n", numList)
