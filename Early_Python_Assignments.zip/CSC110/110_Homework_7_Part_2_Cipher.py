#Author: Dylan Esposito
#Due Date: October 31, 2016
#Homework 7 Part 2
#Purpose: To create a function that uses the autokey method to convert
#plaintext into ciphertext

def autokey(plaintext, codeword):
        #I create a list contianing the 26 letters of the alphabet.
        alphabet=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        #Create a variable called ciphertext that is set equal to an empty string
        ciphertext = ""
        #Create a variable called j that will be used to increment through
        #the plaintext in a loop.
        j = 0

        #Loop that will go through the alphabet and assign characters to the ciphertext.
        for i in range(len(plaintext)):
                #First we check to see if the current value of i is smaller than the
                #codeword parameter. If so we follow the polyalphabetic sequence of assigning
                #the ciphertext.
                if i < len(codeword):
                    #First we create a variable called letter that is assigned to the current element in plaintext.
                    letter = plaintext[i]
                    
                    #Next we create a variable called num_in_alphabet that is assigned to the 
                    num_in_alphabet = alphabet.index(letter)

                    # Find the position in the codeword with the letter to shift
                    shiftIndex = i % len(codeword)
                    
                    # Find the letter in the codeword to shift
                    shiftLetter = codeword[shiftIndex]
                    
                    # Find the number associated with the letter to be used as the shift
                    shift = alphabet.index(shiftLetter)

                    #The cipher_num is set equal to the value produced by the sum of num_alpabet and shift
                    #modded by the length of the alphabet.
                    cipher_num = (num_in_alphabet + shift) % len(alphabet)

                    #From there we set cipher letter equal to the array alphabet at index of ciphernum.
                    cipher_letter = alphabet[cipher_num]

                    #From there we update ciphertext by adding the value of cipherletter to itself.
                    ciphertext = ciphertext + cipher_letter
                else:

                    #First we set the variable letter equal to the value returned with
                    #plaintext at the variable i.
                    letter = plaintext[i]
                    
                    #Next we create a variable called numAlpha and set it equal to the character
                    #that is at the value of letter.
                    num_in_alphabet = alphabet.index(letter)
                    
                    #Next we set shiftLetter to the element j of plaintext.
                    shiftLetter = plaintext[j]
                    
                    #Shift is then set equal to the value at the index of the value in shiftLetter.
                    shift = alphabet.index(shiftLetter)

                    #Next we create a variable called cipher_num and set it equal to the value of numAlpha plus
                    #the value of shift and mod it by the length of alphabet, which is 26.
                    cipher_num = (num_in_alphabet + shift) % len(alphabet)

                    #Cipher Letter is then set equal to index location of the alphabet array.
                    cipher_letter = alphabet[cipher_num]
                    
                    #Next we update the ciphertext by adding cipherletter to it.
                    ciphertext = ciphertext + cipher_letter
                    #Finally we increment j by one.
                    j = j + 1
                    
        return ciphertext
    
