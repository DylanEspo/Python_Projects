#Author: Dylan Esposito
#Due Date: October 3, 2016
#Title: Homework Part 2
#Purpose: This program is meant to simulate the fibonacci number sequence and allow
#the user to enter in what ever value they want for the number of time the sequence runs.

def fib(valEnter):
    #Here we initialize a variable called i that will be used in the loop
    i = 0
    #The previousValue is set to one originally so it can help kickstart the Fibonacci sequence.
    #However as the loop progresses, the previousValue is equivalent to fib[-1]. 
    previousValue = 1
    #We initialize an empty fib array to start off
    fib = []
    
    #The loop runs as long as i is less than the parameter valEnter
    while i < valEnter:
        #Here we check to see if valEnter is less than 1. If it is we just return an empty array.
        if valEnter <= 0:
            return fib
        #This statement is run only when i is equal to zero. 
        elif i == 0:
            #Here fib will just add zero at index zero.
            fib.append(0)
        #This statement is run only when the previous two statements are not met.
        #This is how the fibonacci sequence is supposed to run.
        else:
            #Here the variable previous value adds the value a space before it. In this case. i-2.
            #By adding the two previous values together we get the next number in the sequence.
            previousValue = previousValue + fib[i-2]
            #Afterwords fib will add the variable to the sequence. 
            fib.append(previousValue)
        #After going through all the if statements, we increment i by one.
        i = i + 1
    #Once the whil loop is finished, we simply return the fib array.
    return(fib)
def main():
    #Here we print the fib array when only four values are entered.
    print("The first 4 Fibonacci numbers are", fib(4))
    #Here we print the fib array when only ten values are entered.
    print("The first 10 Fibonacci numbers are", fib(10))
    #Here we print the fib array when a value less than one is entered.
    print(fib(-4))

    
