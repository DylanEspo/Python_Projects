#Author: Dylan Esposito
#Due Date: October 24, 2016
#Title: Homework 6 Question 2
#Purpose: To organize given values alphabetically.

#Here we created function titled openFile that checks to see if the file requested to
#be opened actually exists.
def openFile():

    #Here we create a variable i that is set equal to zero.
    i = 0
    #Here the loop will run until i is not equal to zero.
    while i == 0:
        #We make use of a try and except system that will check to
        #see if the file entered actually exists or not.
        try:
            #The fileName is a variable that has an input assigned to it.
            #In this case the input must be the name of a file followed by .txt
            fileName = input("Please enter the name of the data file: ")
            #If the file is found then we open it and assign it the read operation
            #since all we want to do is collect information from it.
            infile = open(fileName, 'r')
            #From there we end the loop by assigning i equal to one.
            i = 1
            
        #In the except circumstance, we state it is an IOError and
        #we have the compiler return a message to the user.
        except IOError:
            #Here we tell the user that the file does not exist and we ask
            #them to reenter a file that does exist.
            print("File does not exist, try again")
            
    #After we are done we return infile, which is the operation that called the
    #file to be opened.
    return infile


# Function to get the data from the file
def getData():

    #infile is set equal to openFIle 
    infile = openFile()

    #Two empty lists are intialized, yearList and locList.
    yearList = []
    locList = []
    
    line = infile.readline()
    
    while line != "":
        #Here we separate the lines of year and location via the split
        #function. This function will separate the lines upon reaching a
        #specific character. It will also remove that character from the
        #lists.
        line = line.strip()
        year, loc = line.split("\t")
        #Here the array yearList will add the current year line to its collection.
        yearList = yearList + [int(year)]
        #Again locationList will add the current location line to its collection.
        locList = locList + [loc]
        #After the line will read the current line to make sure we all completed.
        line = infile.readline()
    infile.close()
    #Once we complete the list we return both the yearList and locationList
    return yearList, locList

def selectionSort(theList, theList2):
    #Here we set i to zero and the range of values from zero to the length of
    #the given list.
    for i in range(0, len(theList)):
        #Inside we intialize a variable called m and set it equal to i.
        min = i
        #After we use j to search for values in the range of the current
        #value of i to the end of the given list.
        for j in range(i + 1, len(theList)):
            #If we find that the given List at index j is less than the given List
            #at the index of min. We set min equal to j.
            if theList[j] < theList[min]:
                min = j
        #Here we swamp sets of values after exiting the inner loop.
        #We swamp the values of an element in the first list with values from an element
        #somewhere else in that list.
        theList[i], theList[min] = theList[min], theList[i]
        #The same process is done for the second List which is done to keep values inside
        #secondList with the their pairs in the first given List.
        theList2[i], theList2[min] = theList2[min], theList2[i]
    #After we return both lists.
    return theList, theList2

#Here we call the sectionSort function and return the values entered into it.
def dualSort(list1, list2):
    #We use the parameters of list1 and list2 as input parameters for when
    #we call the selectionSort function. 
    selectionSort(list1, list2)
    #After we return both list1 and list2
    return list1, list2

def main():
    #Here we set two lists of yearList an dlocList equal to getData
    yearList, locList = getData()
    #From there we set locList and yearList equal to the dualSort funciton.
    locList, yearList = dualSort(locList, yearList)
    for i in range(len(locList)):
        #Finally we print the yearList and location List
        print(yearList[i], locList[i])
    
