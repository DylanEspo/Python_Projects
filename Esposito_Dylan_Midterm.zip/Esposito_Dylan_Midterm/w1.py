from ubasic_state import state
from grammar_stuff import assert_match


def seq(node):

    (SEQ, stmt, stmt_list) = node
    assert_match(SEQ, 'seq')
    
    walk(stmt)
    walk(stmt_list)

def value_list(node):
    (VAL, value, value_list) = node
    assert_match(VAL, 'val_list')
    
    walk(value)
    walk(value_list)
    
def nil(node):
    
    (NIL,) = node
    assert_match(NIL, 'nil')
    
    # do nothing!
    pass
def end_stmt(node):
    (END,) = node
    assert_match(END, 'Endstmt')
    
    pass

def in_stmt(node):

    (INPUT, name) = node
    assert_match(INPUT, 'Instmt')

def print_stmt(node):
    (PRINT, value, value_list) = node
    assert_match(PRINT, 'Printstmt')
    
def assign_stmt(node):

    (ASSIGN, name, exp) = node
    assert_match(ASSIGN, 'Assignstmt')
    
    walk(exp)

def if_stmt(node):
    (IF, exp, stmt_list, opt_else, endif) = node
    assert_match(IF, 'Ifstmt')

def while_stmt(node):
    (WHILE, exp, stmt_list, endwhile) = node
    assert_match(WHILE, 'Whilestmt')
    
def for_stmt(node):
    #FOR ID '=' exp TO exp opt_step stmt_list NEXT ID
    (FOR, name, start, end, step, stmt_list, name) = node
    assert_match(FOR, 'Forstmt')
          
def integer_value(node):

    (INTEGER, value) = node
    assert_match(INTEGER, 'INTEGER')

#########################################################################
def id_value(node):
    
    (ID, name) = node
    assert_match(ID, 'ID')
    
    # we found a use scenario of a variable, if the variable is defined
    # set it to true
    if name in state.symbol_table:
        state.symbol_table[name] = True

def string_value(node):
    (STRING, name) = node
    assert_match(STRING, 'STRING')
    
#########################################################################
def binop_exp(node):

    (OP, c1, c2) = node
    if OP not in ['+', '-', '*', '/', '==', '<=']:
        raise ValueError("pattern match failed on " + OP)
    
    walk(c1)
    walk(c2)

#########################################################################
def uminus_exp(node):
    
    (UMINUS, e) = node
    assert_match(UMINUS, 'uminus')
    
    walk(e)

#########################################################################
def not_exp(node):
    
    (NOT, e) = node
    assert_match(NOT, 'not')
    
    walk(e)

#########################################################################
def paren_exp(node):
    
    (PAREN, exp) = node
    assert_match(PAREN, 'paren')
    
    walk(exp)

def walk(node):
    node_type = node[0]
    if node_type in dispatch_dict:
        node_function = dispatch_dict[node_type]
        return node_function(node)
    
    else:
        raise ValueError("walk: unknown tree node type: " + node_type)

dispatch_dict = {
    
    'seq'     : seq,
    'val_list' : value_list,
    'nil'     : nil,
    'Instmt' : in_stmt,
    'Printstmt' : print_stmt,
    'Assignstmt' : assign_stmt,
    'Endstmt' : end_stmt,
    'Whilestmt' : while_stmt,
    'Forstmt' : for_stmt,
    'Ifstmt'  : if_stmt,
    'INTEGER' : integer_value,
    'ID'      : id_value,
    'STRING'  : string_value,
    'uminus'  : uminus_exp,
    'not'     : not_exp,
    'paren'   : paren_exp,
    '+'       : binop_exp,
    '-'       : binop_exp,
    '*'       : binop_exp,
    '/'       : binop_exp,
    '=='      : binop_exp,
    '<='      : binop_exp

}