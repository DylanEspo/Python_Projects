from ply import yacc
from ubasic_lex import tokens, lexer
from ubasic_state import state

#Program – A program is a list of statements

precedence = (
              ('left', 'EQ', 'LE'),
              ('left', 'PLUS', 'MINUS'),
              ('left', 'TIMES', 'DIVIDE'),
              ('right', 'UMINUS', 'NOT')
             )

def p_prog(p):
    '''
    program : stmt_list
    '''
    state.AST = p[1]

#########################################################################
def p_stmt_list(p):
    '''
    stmt_list : stmt stmt_list
              | empty
    '''
    if (len(p) == 3):
        p[0] = ('seq', p[1], p[2])
    elif (len(p) == 2):
        p[0] = p[1]

def p_stmt(p):
    '''
    stmt : INPUT opt_string ID
         | PRINT value value_list
         | END
         | IF exp THEN stmt_list opt_else ENDIF
         | WHILE exp stmt_list ENDWHILE
         | FOR ID '=' exp TO exp opt_step stmt_list NEXT ID
         | ID '=' exp
    '''
    if p[1] == 'input':
        p[0] = ('Instmt', p[3])
    elif p[1] == 'end':
        p[0] = ('Endstmt',)
    elif p[1] == 'print':
        p[0] = ('Printstmt', p[2], p[3])  
    elif p[1] == 'if':
        p[0] = ('Ifstmt', p[2], p[4], p[5], p[6])
    elif p[1] == 'while':
        p[0] = ('Whilestmt',p[2], p[3], p[4])
    elif p[1] == 'for':
        p[0] = ('Forstmt', p[2], p[4], p[6], p[7], p[8], p[10])
    elif p[2] == '=':
        p[0] = ('Assignstmt', p[1], p[3])
        
    
def p_opt_string(p):
    '''
    opt_string : STRING ','
               | empty
    
    '''
    if p[1] == 'STRING':
        p[0] = (p[1], p[2])
    else:
        p[0] = p[1]

def p_value_list(p):
    '''
    value_list : ',' value value_list
                | empty
    '''
    if(p[1] == ','):
        p[0] = ('val_list', p[2], p[3])
    else:
        p[0] = p[1]
    
def p_opt_else(p):
    '''        
    opt_else : ELSE stmt_list
             | empty
    '''
    if(p[1] == 'else'):
        p[0] = p[2]
    else:
        p[0] = p[1]
        
def p_opt_step(p):
    '''
    opt_step : STEP exp
             | empty
    '''
    if(p[1] == 'step'):
        p[0] = (p[2])
    else:
        p[0] = p[1]
def p_value_id(p):
    '''
    value : ID
    '''
    p[0] = ('ID', p[1])

def p_value_integer(p):
    '''
    value : INTEGER
    '''
    p[0] = ('INTEGER', int(p[1]))

def p_value_string(p):
    '''
    value : STRING
    '''
    p[0] = ('STRING', str(p[1]))        
        
        
def opt_else(p):
    '''
    opt_else : ELSE stmt_list
             | empty
    '''
    if p[1] == 'else':
        p[0] = p[2]
    else:
        p[0] = p[1]

def opt_step(_):
    '''         
    opt_step : STEP exp
             | empty
    '''
    pass
    
def p_bin_exp(p):
    '''
    exp : exp PLUS exp
        | exp MINUS exp
        | exp TIMES exp
        | exp DIVIDE exp
        | exp EQ exp
        | exp LE exp
        | exp AND exp
        | exp OR exp
    '''
    p[0] = (p[2], p[1], p[3])
    
def p_exp_integer(p):
    
    '''
    exp : INTEGER
    
    '''
    p[0] = ('INTEGER', int(p[1]))
    
def p_exp_id(p):
    '''
    exp : ID
    
    '''
    p[0] = ('ID', p[1])
            
def p_paren_exp(p):
    '''
    exp : '(' exp ')'
    '''
    p[0] = ('paren', p[2])
            
           
def p_not_exp(p):
    '''
    exp : NOT exp
    '''
    p[0] = ('not', p[2])

def p_uminus_exp(p):
    '''
    exp : MINUS exp %prec UMINUS
    '''
    p[0] = ('uminus', p[2])

def p_empty(p):
    'empty :'
    p[0] = ('nil',)
    pass

def p_error(t):
    print(t)
    print("Syntax error at '%s'" % t.value)
    
#########################################################################
# build the parser
#########################################################################
parser = yacc.yacc(debug=False,tabmodule='midtermparsetab')