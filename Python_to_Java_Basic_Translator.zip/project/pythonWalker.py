from state import state
from grammar_stuff import assert_match

indent_level = 3

#seq function, used when a segment of the tree contains other functions
def seq(node):
    (SEQ, s1, s2) = node
    assert_match(SEQ, 'seq')
    stmt = walk(s1)
    list = walk(s2)
    return str(stmt) + list

#########################################################################
#Nil function used when the values are empty
def nil(node):
    
    (NIL,) = node
    assert_match(NIL, 'nil')
    
    return ''

#Class function used when reading python classes and creating standard java classes
def class_stmt(node):
    global indent_level
    
    #pattern matching for class_stmt
    (class_stmt, name, stmt_list) = node
    assert_match(class_stmt, 'class_stmt')
    
    #create a class category within the symbol table
    state.symbol_table[name] = ('CLASS', stmt_list)
    
    #walk the body of the class
    body = walk(stmt_list)
    
    #create outline for java code
    code = "public class " + name + '{' + '\n'
    code2 = indent() + str(body) + '\n'
    finalCode = code + code2
    
    return finalCode

def class_call(node):
    global indent_level
    (class_call, varName, name, exp) = node
    
    assert_match(class_call, 'class_call')
    
    print("In class Call")
    
    className = walk(name)
    
    inputVals = walk(exp)
    
    state.symbol_table[varName] = ('CLASS', name)
    
    code =  indent() + className + varName + '=' + clasName + '(' + str(inputVals) + ')'
    
    return code

#Used for reading functions in python
def def_stmt(node):
    
    #pattern matching performed here
    global indent_level
    (def_stmt, name, params, stmt_list) = node
    assert_match(def_stmt, 'def_stmt')
    
    #walk values generating the paraemters for the function
    values = walk(params)
    #strip the values of a comma left over when separating them
    values = values[:-1]
    code = '\n' + indent() + 'public method void ' + name + '(' + str(values) + ')' + '{\n'
    
    indent_level+=1
    
    #walk body and then set it equal to code2
    body = walk(stmt_list)
    code2 = str(body) + '\n'
    
    indent_level-=1
    
    code3 = indent() +  '}'
    
    #combine all the segments to form the proper output
    finalCode = code + code2 + code3
    
    return finalCode    
    
def return_stmt(node):
    global indent_level
    (return_stmt, opt) = node
    assert_match(return_stmt, 'return_stmt')
    
    code = "\n" + indent() + "return " + str(opt[1]) + ';'
    
    return code
    
#########################################################################
#Reads print statments from python
def sysout_stmt(node):
    global indent_level
    
    #pattern matching
    (sysout, exp) = node
    assert_match(sysout, 'sysout')
    
    #produces correct Java syntax and stores values within parantheses
    code = "\n" + indent() + 'System.out.println' + '(' + str(exp[1]) + ');'
    #print(str(code))
    return code

#assignment statement used for declaring variables
def assign_stmt(node):
    global indent_level    
        
    (ASSIGN, name, exp) = node
    assert_match(ASSIGN, 'assign')
    
    code = ' '
        
    #check if given variable is already within table
    if name in state.symbol_table:
        #walk through and recover assignment
        exp_code = walk(exp)
        #remove # that is attached to integers to help separate them from one another
        exp_code = exp_code.replace('#', '')
        #write java syntax and then send to interp
        code = "\n" + indent() + name + ' = ' + str(exp_code) + ';\n'
        return code
    
    #checks if we are assigning a boolean, if so we assign it to the BOOL category
    elif str(exp[1]) == 'true' or str(exp[1]) == 'false':
        state.symbol_table[name] = ('BOOL', exp[1])
        code = "\n" + indent() + 'Boolean ' + name + ' = ' + exp[1] + ';\n'
        return code
    #Otherwise we are assuming to be creating a new variable and will walk through
    #checking where it belongs and what type of value it is
    else:
        exp_code = walk(exp)
        exp_code = exp_code.replace('#', '')
        if(exp[0] == 'STRING'):       
            if len(exp_code) == 3:
                state.symbol_table[name] = ('CHAR', exp_code)
                code = "\n" + indent() + 'char ' + name + ' = ' + str(exp_code) + ';\n'
                #print(code)
                return code
            else:
                state.symbol_table[name] = ('STRING', exp_code)
                code = "\n" + indent() + 'char[] ' + name + ' = ' + str(exp_code) + ';\n'
                #print("\t" + code)
                return code
        else:                         
            #print("Try passed")      
            state.symbol_table[name] = (exp)
            code = indent() + 'int ' +  name + ' = ' + str(exp_code) + ';\n'
            #print(code)
            return code
        
#Reads python arrays and converts them to java arrays   
def array(node):
    global indent_level
    (array, name, opt_args) = node
    assert_match(array, 'array') 
    
    #Walk through the valeus inside the array
    exp_code = walk(opt_args)
    
    #Replace the # attached to each integer with a comma
    exp_code = exp_code.replace('#', ',')
    #Remove the final comma attached to the array
    exp_code = exp_code[:-1]
    code = ""
    
    #Check if the array is an integer, if so then we perform the same operations
    if str(opt_args[1][0]) == 'INTEGER':
        #Insert into symbol table and then create java code
        state.symbol_table[name] = ('INTEGER', opt_args)  
        code = indent() + "int[] " + name + ' = ' + "{" + str(exp_code) + "}" + ';'
        return code
    
    #Check if array is composed of strings, if so then we perform the same operations
    elif str(opt_args[1][0]) == 'STRING' or str(opt_args[1][0]) == 'CHAR':
        state.symbol_table[name] = ('STRING', opt_args)
        code = "\n" + indent() + "String[] " + name + ' = ' + "{" + str(x) + "}" + ';\n'
        return code
    
    return code

#Reads python conditional statements
def if_stmt(node):
    global indent_level
    (if_stmt, exp, s1, opt) = node
    assert_match(if_stmt, 'if_stmt')
      
    condStmt = walk(exp)

    code = "\n" + indent() + "if " + "(" + str(condStmt) + ")"
    indent_level+=1
    insideStmt = walk(s1)
    code+= "{" + indent() + str(insideStmt)
    indent_level-=1
    code+="\n" + indent() + "}"
   
    optStmt = walk(opt)
    code+="\n" + optStmt
    #Instead of printing the statement list outcome, it appears that the desired output is already printed since we are
    #walking through the grammar tree which leads us to the print statement
    return code

#Reads python conditional else statements
def else_stmt(node):
    global indent_level
    (else_stmt, stmt_list) = node
    
    assert_match(else_stmt, 'else_stmt')
   
    code = indent() + "else" + "{\n" 
    indent_level+=1
    
    #Walk the stmt_list and output the given statements
    exp_code = walk(stmt_list)
    code+= indent()+ str(exp_code) +"\n"
    #reset the indent level
    indent_level-=1
    code+=indent() + "}"
    return code
#Reads python for loops
def for_stmt(node):
    global indent_level
    (for_stmt, exp, rangeVals, stmt_list) = node   
    
    code = indent() +  'for(' 
    previous_indent = indent_level
    indent_level = 0
    
    #call assignstmt to either create or update the counter variable
    node2 = ('assign', exp[1], rangeVals[1])
    exp_code = assign_stmt(node2)
    exp_code = exp_code.replace('\n', '')
    
    #Creates endpoint for the range of vals
    cond = walk(rangeVals)
    
    #Add more to the java syntax
    code+= str(exp_code) + str(exp[1]) + '<='  + str(cond[1]) + '; ' + str(exp[1]) + '++)' + '{'
    
    #Reset indent levels
    indent_level = previous_indent
    indent_level+=1
    
    #Walk body through the rest of the CONDIT
    body = walk(stmt_list)
    
    code+= '\n' + indent() + str(body) + '\n'
    indent_level-=1
    code+= indent() + '}\n'
    return code
    
#Reads python code stored in while loop
def while_stmt(node):
    global indent_level
    (while_stmt, exp, stmt_list) = node
    assert_match(while_stmt, 'while_stmt')
    
    #Walks to locate condition for how long the loop will go on for
    cond = walk(exp)
    
    code = '\n' + indent() + 'while' + '(' + str(cond) + '){'
    indent_level+=1
    
    #Walk list of statements stored in body
    body = walk(stmt_list)
    code+= indent() + str(body) + '\n'\
    
    indent_level-=1
    code+= indent() + '}\n'
    return code
    
    
def binop_exp(node):

    (OP, c1, c2) = node
    if OP not in ['+', '-', '*', '/', '==', '<=', '%',',']:
        raise ValueError("pattern match failed on " + OP)
    
    lcode = walk(c1)
    lcode = str(lcode)
    lcode = lcode.replace('#', '')
    
    
    rcode = walk(c2)
    rcode = str(rcode)
    rcode = rcode.replace('#', '')
    
    code = ' '
    
    #Determine what operation is being performed
    if OP == '-':
        code = str(lcode) + ' - ' + str(rcode)
    elif OP == ',':
        code = str(lcode) + ' , ' + str(rcode)
    elif OP == '+':
        code = str(lcode) + ' + ' + str(rcode)
    elif OP == '*':
        code = str(lcode) + ' * ' + str(rcode) 
    elif OP == '/':
        code = str(lcode) + ' / ' + str(rcode) 
    elif OP == '<=':
        code = str(c1[1]) + ' <= ' + str(rcode)
    elif OP == '%':
        code = str(c1[1]) + ' % ' + str(rcode)
    return code

#########################################################################
def integer_value(node):
    
    (INTEGER, value) = node
    assert_match(INTEGER, 'INTEGER')
    code = value
    #Attach # at the end so we can separate values and replace them with commas if need be.
    return str(value) + '#'

#Identifies if boolean value
def boolean_value(node):
    
    (BOOLEAN, value) = node
    assert_match(BOOLEAN, 'BOOLEAN')
    code = value
    return code

#########################################################################
#Identifies if it is an ID
def id_value(node):
    
    (ID, name) = node
    assert_match(ID, 'ID')
   
    #Checks if value is located within symbol table
    if name in state.symbol_table:
        z = state.symbol_table[name]
        code = z[1]
        return code
    #check if given value is true or false, will reassign it to BOOLEAN
    elif name == 'true' or name == 'false':
        return name
    #This is the condition that specifically looks at parameters. Adds a comma at the end
    else:
        state.symbol_table[name] = ('ID', name)
        return 'int ' + name + ','

#Specifically done for String values
def string_value(node):
    (STRING, name) = node
    assert_match(STRING, 'STRING')
    code = name
    return code

#Specific check for values stored as classes
def class_value(node):
    (CLASS, name) = node
    assert_match(CLASS, 'CLASS')
    code = name
    return code

#Walks through and tries to identify correct function to use
def walk(node):
    #print(node[0])
    node_type = node[0]
    if node_type in dispatch_dict:
        node_function = dispatch_dict[node_type]
        return node_function(node)
    
    else:
        raise ValueError("walk: unknown tree node type: " + node_type)

dispatch_dict = {
    'seq'     : seq,
    'nil'     : nil,
    'sysout'   : sysout_stmt,
    'assign'  : assign_stmt,
    'array'   : array,
    'if_stmt'  : if_stmt,
    'else_stmt' : else_stmt,
    'while_stmt' : while_stmt,
    'class_call' : class_call,
    'class_value' : class_value,
    'for_stmt' : for_stmt,
    'def_stmt' : def_stmt,
    'class_stmt' : class_stmt,
    'return_stmt' : return_stmt,
    'binop'   : binop_exp,
    'INTEGER' : integer_value,
    'ID'      : id_value,
    'STRING'  : string_value,
    'BOOLEAN' : boolean_value,
    '+'       : binop_exp,
    '-'       : binop_exp,
    '*'       : binop_exp,
    '/'       : binop_exp,
    '=='      : binop_exp,
    '<='      : binop_exp,
    '%'       : binop_exp,
    ','       : binop_exp,

}

def indent():
    s = ''
    for i in range(indent_level):
        s += '   '
    return s

#########################################################################
def init_indent_level():
    global indent_level
    indent_level = 3