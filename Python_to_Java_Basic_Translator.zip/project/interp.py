#!/usr/bin/env python
# Cuppa1 pretty printer

from sys import stdin
from gram import parser
from lexer import lexer
from state import state
from pythonWalker import walk as walker


def pp(input_stream = None, input_stream2 = None):

    #if no input stream was given, we enclose the main in a default class
    if not input_stream:
        input_stream = stdin.read()
        print("public class default {")

    # initialize the state object and indent level
    state.initialize()
    #init_indent_level()
    
    # build the first AST for the given class framework
    parser.parse(input_stream, lexer=lexer)

    # walk the AST for the class framework
    code = walker(state.AST)
    
    
    # output the pretty printed code
    print(code)
    
    #Now we walk the input_stream that will be placed into the main
    parser.parse(input_stream2, lexer=lexer)
    #Now we walk through that AST to create the correct Java code
    code2 = walker(state.AST)
    
    print("\t" + "public static void main(String[]args) {")
    print(code2)
    
    print(" \n\t}")
    print("}")
if __name__ == "__main__":
    # execute only if run as a script
    pp()
