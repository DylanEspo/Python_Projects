# Lexer for project

from ply import lex

reserved = {
    'input'     : 'INPUT',
    'print'     : 'PRINT',
    'sysout'    : 'SYSOUT',
    'assign'    : 'ASSIGN',
    'array'     : 'ARRAY',
    'declare'   : 'DECLARE',
    'if'        : 'IF',
    'then'      : 'THEN',
    'else'      : 'ELSE',
    'elif'      : 'ELIF',
    'while'     : 'WHILE',
    'for'       : 'FOR',
    'to'        : 'TO',
    'pass'      : 'PASS',
    'in'        : 'IN' ,
    'range'     : 'RANGE',
    'def'       : 'DEF',
    'class'     : 'CLASS',
    'pass'      : 'PASS',
    'return'    : 'RETURN',
}

literals = ['+', '-','/','*','%','=','(',')',',',':','[',']',]

tokens = ['EQ','LE','AND','OR','NOT',
          'INTEGER','ID','STRING', 'BOOLEAN',
          ] + list(reserved.values())

t_EQ      = r'=='
t_LE      = r'<='
t_AND     = r'\&'
t_OR      = r'\|'
t_NOT     = r'!'

t_ignore = ' \t'

def t_ID(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    t.type = reserved.get(t.value,'ID')    # Check for reserved words
    return t

def t_INTEGER(t):
    r'[0-9]+'
    return t

def t_STRING(t):
    r'\"[^\"]*\"'
    #t.value = t.value[1:-1] # strip the quotes
    return t

def t_COMMENT(t):
    r'\'.*'
    pass

def t_NEWLINE(t):
    r'\n'
    pass

def t_error(t):
    print("Illegal character %s" % t.value[0])
    t.lexer.skip(1)

# build the lexer
lexer = lex.lex(debug=0)
