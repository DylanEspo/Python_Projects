from ply import yacc
from lexer import tokens,lexer
from state import state

def p_prog(p):
    '''
    prog : stmt_list
    
    '''
    state.AST = p[1]

def p_stmt_list(p):
    '''
    stmt_list : empty
              | PASS
              | stmt stmt_list
    '''
    #print(str(p[1]))
    if (len(p) == 2 or p[1] == 'pass'):
        #print(str(p[1]))
        p[0] = ('nil',)
    elif (len(p) == 3):
        p[0] = ('seq', p[1], p[2])
        
def p_stmt(p):
    '''
    stmt : CLASS ID ':' stmt_list
         | ID '=' CLASS '(' opt_args ')'
         | PRINT '(' exp ')' 
         | ID '=' '[' opt_args ']'
         | ID '=' exp 
         | IF  exp ':' stmt_list opt 
         | WHILE exp ':' stmt_list
         | FOR exp IN RANGE '(' opt_args ')' ':' stmt_list
         | DEF ID '(' opt_args ')' ':' stmt_list
         | RETURN opt_exp
         
    '''
    if p[1] == 'print':
        p[0] = ('sysout', p[3])
    elif p[3] == 'CLASS':
        print("In class Call")
        p[0] = ('classCall',p[1],p[3], p[5])
    elif p[1] == 'return':
        p[0] = ('return_stmt',p[2])
    elif p[3] == '[':
        print(p[5])
        p[0] = ('array', p[1], p[4])
    elif p[2] == '=':
        #print(str(p[3]))
        p[0] = ('assign', p[1], p[3])
    elif p[1] == 'if':
        #print('Here in if')
        p[0] = ('if_stmt',p[2], p[4], p[5])
    elif p[1] == 'while':
        p[0] = ('while_stmt', p[2], p[4])
    elif p[1] == 'for':
        p[0] = ('for_stmt', p[2], p[6], p[9])
    elif p[1] == 'def': 
        p[0] = ('def_stmt', p[2], p[4], p[7])
    elif p[1] == 'class':
        p[0] = ('class_stmt',p[2], p[4])
    else:
        print("Syntax error")

def p_opt(p):
    '''
    opt : ELSE ":" stmt_list
        | empty
    '''
    #print("This is " + p[1])
    if p[1] == "else":
        p[0] = ('else_stmt', p[3])
    else:
        p[0] = p[1]
        
def p_opt_args(p):
    '''
    opt_args : extra_args
                  | empty
    '''
    p[0] = p[1]

def p_extra_args(p):
    '''
    extra_args : exp ',' extra_args
               | exp
    '''
    #print(str(p[1]))
    if (len(p) == 4):
        p[0] = ('seq', p[1], p[3])
    elif (len(p) == 2):
        p[0] = ('seq', p[1], ('nil',))

def p_opt_exp(p):
    '''
    opt_exp : exp
            | empty
    '''
    p[0] = p[1]
        
def p_exp(p):
    '''
    exp : exp '+' exp
        | exp '-' exp
        | exp '*' exp
        | exp '/' exp
        | exp '%' exp
        | exp LE exp
        | empty
    '''
    p[0] = (p[2], p[1], p[3])

def p_exp_bool(p):
    '''
    exp : BOOLEAN
    
    '''
    p[0] = ('BOOLEAN', p[1])
    
def p_exp_id(p):
    '''
    exp : ID
    '''
    p[0] = ('ID', p[1])

def p_exp_integer(p):
    '''
    exp : INTEGER
    '''
    p[0] = ('INTEGER', int(p[1]))

def p_exp_string(p):
    '''
    exp : STRING
    '''
    p[0] = ('STRING', p[1])     

def p_exp_class(p):
    '''
    exp : CLASS
    '''
    p[0] = ('CLASS', p[1])
def p_empty(p):
    '''
    empty :
    
    '''
    p[0] = ('nil',)
    
def p_error(t):
    print("Syntax error at '%s'" % t.value)

#########################################################################
# build the parser
#########################################################################
parser = yacc.yacc(debug=False,tabmodule='pythonToJavaTranslator')
    